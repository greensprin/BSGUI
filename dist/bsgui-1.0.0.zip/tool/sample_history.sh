#!/bin/bash

g++ -v
