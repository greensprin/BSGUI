bsub -Is -q re7bat letency_opt
