bsub -Is -q re7int derate_opt
