import sys
import time

# time.sleep(3)

# print("Hello, World")
print(sys.argv)
sys.stdout.flush()